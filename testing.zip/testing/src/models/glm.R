rm(list = ls())
library(data.table)
library(caret)
library(Metrics)
library(plotmo)
library(tidyverse)

train<-fread("~/Desktop/STAT380/testing/volume/data/interim/train.csv")
test<-fread("~/Desktop/STAT380/testing/volume/data/interim/test.csv")
example_sub<-fread("~/Desktop/STAT380/testing/volume/data/raw/example_sub.csv")

drops<- c('team_1','team_2','Season','DayNum')

train<-train[, !drops, with = FALSE]
test<-test[, !drops, with = FALSE]
train_y<-train$result
model <- glm(result ~.,family=binomial,data=train)
summary(model)
anova(model)


select<-c('result','BWE_dif','DOK_dif','EBP_dif','FSH_dif',
          'WIL_dif','DES_dif','SP_dif','RTH_dif','ZAM_dif','SMS_dif','KPI_dif',
          'MGS_dif')
train<-train[, select, with = FALSE]
test<-test[, select, with = FALSE]
glm_model <- glm(result~., family = binomial, data = train)
pred<-predict(glm_model,newdata = test, type = "response")
example_sub$result<-pred
fwrite(example_sub,"~/Desktop/STAT380/testing/volume/data/submit_3.csv")
