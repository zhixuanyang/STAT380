library(data.table)
library(dplyr)
set.seed(77)

test<-fread('~/Desktop/STAT380/testing/volume/data/raw/example_sub.csv')
season<-fread('~/Desktop/STAT380/testing/volume/data/raw/season.csv')
tourney<-fread('~/Desktop/STAT380/testing/volume/data/raw/tourney.csv')
ranks<-fread('~/Desktop/STAT380/testing/volume/data/raw/ranks.csv')


test$id<-sub(".+?_","",test$id)

test$id<-sub(".+?_","",test$id)

test<-data.table(matrix(unlist(strsplit(test$id,"_")),ncol=2,byrow=T))
setnames(test,c("V1","V2"),c("team_1","team_2"))

test$Season<-2019
test$DayNum<-120


test$id_num<-1:nrow(test)

test<-test[,.(id_num,team_1,team_2,Season,DayNum)]

test$result<-0.5

season=season[Season==2019]
tourney=tourney[Season==2019]
train<-rbind(season,tourney)
train<-train[,.(WTeamID,LTeamID,Season,DayNum)]
setnames(train,c("WTeamID","LTeamID"),c("team_1","team_2"))

train$result<-1

train$id_num<-1:nrow(train)

# make master data file

master<-rbind(train,test)
master$team_1<-as.character(master$team_1)
master$team_2<-as.character(master$team_2)

ranks$DayNum<-ranks$RankingDayNum+1

ranks<-ranks[Season==2019]
system_lst<-unique(ranks$SystemName)


for (i in 1:length(system_lst)){
  
  one_rank<-ranks[SystemName==system_lst[i]][,.(Season,DayNum,TeamID,OrdinalRank)]
  setnames(one_rank,"TeamID","team_1")
  
  one_rank$team_1<-as.character(one_rank$team_1)
  
  setkey(master,Season,team_1,DayNum)
  setkey(one_rank,Season,team_1,DayNum)
  
  master<-one_rank[master,roll=T]
  setnames(master,"OrdinalRank","team_1_rank")
  
  
  setnames(one_rank,"team_1","team_2")
  setkey(master,Season,team_2,DayNum)
  setkey(one_rank,Season,team_2,DayNum)
  
  master<-one_rank[master,roll=T]
  
  setnames(master,"OrdinalRank","team_2_rank")
  
  master$rank_dif<-master$team_2_rank-master$team_1_rank
  
  master$team_1_rank<-NULL
  master$team_2_rank<-NULL
  
  setnames(master,"rank_dif",paste0(system_lst[i],"_dif"))
  
}

master<-master[order(Season,DayNum)]
for (i in names(master)){
  set(master,which(is.na(master[[i]])),i,0)
}
master<-master[order(Season,DayNum)]




################ 
test<-master[result==0.5]
train<-master[result==1]
test<-test[order(id_num)]

test$id_num<-NULL
train$id_num<-NULL

rand_inx<-sample(1:nrow(train),nrow(train)*0.5)
train_a<-train[rand_inx,]
train_b<-train[!rand_inx,]

train_b$result<-0
for(i in 1:length(system_lst)){
  train_b[[paste0(system_lst[i],'_dif')]]<-train_b[[paste0(system_lst[i],'_dif')]]*-1
}

train<-rbind(train_a,train_b)

fwrite(test,'~/Desktop/STAT380/testing/volume/data/interim/test.csv')
fwrite(train,'~/Desktop/STAT380/testing/volume/data/interim/train.csv')

